import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import EducationSection from "@/components/EducationSection";
import SpecialtySection from "@/components/SpecialtySection";
import AwardsSection from "@/components/AwardsSection";
import TreatmentsSection from "@/components/TreatmentsSection";
import GallerySection from "@/components/GallerySection";
import LocationsSection from "@/components/LocationsSection";
import ContactSection from "@/components/ContactSection";
import AppointmentBookingSection from "@/components/AppointmentBookingSection";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <HeroSection />
      <EducationSection />
      <SpecialtySection />
      <AwardsSection />
      <TreatmentsSection />
      <GallerySection />
      <LocationsSection />
      <AppointmentBookingSection />
      <ContactSection />
      <Footer />
    </div>
  );
};

export default Index;
