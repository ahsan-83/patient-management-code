import api from "./apiService";


export const addPatient = async (data) => {

    return api.post('/patients/addpatient', data);
};


export const addSingleConsultation = async (data) => {

    return api.post('/consultation/addconsultation', data);
}