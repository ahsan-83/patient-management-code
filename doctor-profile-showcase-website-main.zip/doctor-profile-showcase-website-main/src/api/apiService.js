import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:3000',
  headers: {
    'Content-Type': 'application/json',
  },
});

let isRefreshing = false;
let failedQueue = [];

const processQueue = (error, token = null) => {
  failedQueue.forEach(prom => {
    if (error) prom.reject(error);
    else prom.resolve(token);
  });
  failedQueue = [];
};

// Request Interceptor: attach both tokens
api.interceptors.request.use(
  (config) => {
    const bmdc = "YT781GTWQQ";

    if (bmdc) {
      config.headers['bmdc'] = bmdc;
    }

    return config;
  },
  (error) => Promise.reject(error)
);


export default api;
